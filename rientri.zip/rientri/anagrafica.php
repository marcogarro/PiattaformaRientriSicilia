<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username=$row["email"];

require_once('funzioni.php');
?>
<html>
<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="./stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="./stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://www.google.com/recaptcha/api.js" async defer></script>
		<title>Denuncia Rientro</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
</script>
</head>
<body>
<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa
<br>
Denuncia Rientro da Zone a Rischio
</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$nome_utente; ?></b></p>
<p><a class="button" href = "scadenza.php">In scadenza</a> <a class="button" href = "welcome.php">In isolamento</a> <a class="button" href = "nominativo.php?nominativo=">Tutti</a> <a class="button" href = "export.php">Esporta</a></p>
<p class="evidenza">Tutti i campi seguenti sono obbligatori</p>
<form action="./conferma.php" method="POST">
	<p><label for="Paese_di_provenienza"><b>Paese di Provenienza</b>:</p>
	<?php
		//$sql = "SELECT denominazione, nomefile FROM zone_rischio GROUP BY denominazione ORDER BY denominazione ASC";
		$sql = "SELECT stato FROM nazioni ORDER BY stato ASC";
		$ris = mysqli_query($link,$sql);
		echo '<select name="Paese_di_provenienza">';
		while($row = mysqli_fetch_array($ris)){
		  //echo '<div class="centri_vaccinali">';
		  //echo '<input type="radio"  name="Paese_di_provenienza" value="'.$row["nomefile"].'" required>';
          //echo '<label for="'.$row["nomefile"].'" class="scelta">'.$row["denominazione"].'</label>';
          //echo '</div>';
          echo '<option value="'.$row["stato"].'">'.$row["stato"].'</option>';
		}
		echo '</select>';
	?>
	<p class="sottotitolo">Inserire i dati personali del soggetto che rientra nella Provincia di Siracusa</p>
    
    <p><label for="Cognome"><b>Cognome</b>:</p>
	<p><input type="text" name="Cognome" required size="40"></p>
	
	<p><label for="Nome"><b>Nome</b>:</p>
	<p><input type="text" name="Nome" required size="40"></p>
	
	<p><label for="Data_di_nascita"><b>Data di Nascita</b></p>
	<!-- <p><input type="date" name="Data_Nascita" required></p>-->
	<p>
		<select name="Giorno">
			<?php 
				$corrente = date("d");
				for($i = 1; $i <=31; $i++){
					if($i == date("d")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
		<select name="Mese">
			<?php 
				$corrente = date("m");
				for($i = 1; $i <=12; $i++){
					if($i == date("m")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
		<select name="Anno">
			<?php 
				$corrente = date("Y");
				for($i = $corrente; $i >1910; $i--){
					if($i == date("Y")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
	</p>
	<p><label for="Luogo_di_nascita"><b>Luogo di Nascita</b>:</p>
	<p><input type="text" name="Luogo_di_nascita" required size="40"></p>
	<p><label for="Sesso"><b>Sesso</b>:</p>
	<p>
	   <select name="Sesso">
	       <option value="M">Maschio</option>
	       <option value="F">Femmina</option>
	   </select>
	</p>
	<!-- <p><input type="text" name="Sesso" required size="1"></p> -->

	<p><label for="Codice_Fiscale"><b>Codice Fiscale</b>:</p>
	<p><input type="text" name="Codice_Fiscale" required size="16"></p>
	
	<p><label for="Luogo_di_residenza"><b>Luogo Residenza</b>:</p>
	<p><input type="text" name="Luogo_di_residenza" required size="40"></p>
	
	<p><label for="Indirizzo_di_residenza"><b>Indirizzo Residenza</b>:</p>
	<p><input type="text" name="Indirizzo_di_residenza" required size="40"></p>
	
	<p><label for="Cellulare"><b>Cellulare</b>:</p>
	<p><input type="text" name="Cellulare" required size="10"></p>
	
	<p><label for="email"><b>E-Mail</b>:</p>
	<p><input type="text" name="email" required size="40"></p>
	
	<!-- 
	<p><label for="Comune_di_destinazione"><b>Comune di Destinazione</b>:</p>
	<p><input type="text" name="Comune_di_destinazione" required size="40"></p>
	-->
	<p><label for="Comune_di_destinazione"><b>Comune di Destinazione</b>:</p>
	<p>
        <select name="Comune_di_destinazione">
        <?php 
				$sql_com = "SELECT * FROM comuni ORDER BY nomefile ASC";
				echo $sql_com;
				$ris_com = mysqli_query($link,$sql_com);
				while($row_com = mysqli_fetch_array($ris_com)){
				    
				    if($row_com["nomefile"] == "Siracusa"){
				        echo '<option value="'.$row_com["denominazione"].'" selected>'.$row_com["denominazione"].'</option>';
				    }else echo '<option value="'.$row_com["denominazione"].'">'.$row_com["denominazione"].'</option>';
				}
			?>
        </select>
	</p>
	
	<p><label for="Indirizzo_di_destinazione"><b>Indirizzo di Destinazione</b>:</p>
	<p><input type="text" name="Indirizzo_di_destinazione" required size="40"></p>
	
	<p><label for="Data_di_partenza"><b>Data di partenza:</b></p>
	<p>
		<select name="P_Giorno">
			<?php 
				$corrente = date("d");
				for($i = 1; $i <=31; $i++){
					if($i == date("d")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
		<select name="P_Mese">
			<?php 
				$corrente = date("m");
				for($i = 1; $i <=12; $i++){
					if($i == date("m")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
		<select name="P_Anno">
			<?php 
				$corrente = date("Y");
				for($i = $corrente; $i >1910; $i--){
					if($i == date("Y")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
	</p>
	
	<p><label for="Data_di_arrivo"><b>Data di arrivo:</b></p>
	<p>
		<select name="A_Giorno">
			<?php 
				$corrente = date("d");
				for($i = 1; $i <=31; $i++){
					if($i == date("d")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
		<select name="A_Mese">
			<?php 
				$corrente = date("m");
				for($i = 1; $i <=12; $i++){
					if($i == date("m")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
		<select name="A_Anno">
			<?php 
				$corrente = date("Y");
				for($i = $corrente; $i >1910; $i--){
					if($i == date("Y")){
						echo '<option value="'.$i.'" selected>'.$i.'</option>';
					}else{ echo '<option value="'.$i.'">'.$i.'</option>'; }
				}
			?>
		</select>
	</p>
    
    <p><label for="Stato_di_salute"><b>Stato di Salute</b>:</p>
	<p><input type="text" name="Stato_di_salute" required size="40"></p>
	
	
	<input type="submit" name="Invia" value="INVIA">
	
</form>
<p><a class="button" href = "logout.php">Esci</a></p>
</div>
</body>
</html>
