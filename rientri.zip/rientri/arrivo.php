<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username=$row["email"];

require_once('funzioni.php');
?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="../stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="../stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Rientri 1.0</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Piattaforma Gestione Rientri</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$nome_utente; ?></b></p>

<p><a class="button" href = "arrivo.php">Aggiorna</a> <a class="button" href = "scadenza.php">In scadenza</a> <a class="button" href = "welcome.php">In isolamento</a> <a class="button" href = "nominativo.php?nominativo=">Tutti</a> <a class="button" href = "export.php">Esporta</a></p>
<form action="scadenza.php" method="post">
    Cerca per data di fine quarantena: 
                                        <input type="date" name="riferimento">
                                        <input type="submit" class="pulsante_cerca" value="Cerca">
</form>
<form action="arrivo.php" method="post">
    Cerca per data di inizio quarantena: 
                                        <input type="date" name="riferimento_inizio">
                                        <input type="submit" class="pulsante_cerca" value="Cerca">
</form>
<form action="nominativo.php" method="post">
    Cerca per cognome: 
                                        <input class="cognome" type="text" name="nominativo">
                                        <input type="submit" class="pulsante_cerca" value="Cerca">
</form>

<table class="elenco">
<tr class="top_row"><td>AI</td><td>AF</td><td>ID</td><td>Cognome</td><td>Nome</td><td>Data di Nascita</td><td>Luogo di Nascita</td><td>CF</td><td>Cellulare</td><td>Email</td><td>Provenzienza</td><td>PSA</td><td>Destinazione</td><td>Data di Arrivo</td><td>Fine Quarantena</td><td>Ultima Modifica</td><td>Dettagli</td></tr>
<?php 

if(isset($_POST["ID"])){
    $sblocca = sblocca($_POST["ID"],$tabella_dati,$link,$username);
}
if(isset($_POST["riferimento_inizio"])){
    $sql_count = "SELECT count(*) as count FROM ".$tabella_dati." WHERE archiviato = 0 AND Data_di_arrivo = '".$_POST["riferimento_inizio"]."'";
    //echo $sql_count."<br>";
    $ris_count = mysqli_query($link,$sql_count);
    $count = mysqli_fetch_array($ris_count);
    echo "Isolamenti iniziati il ".inversa($_POST["riferimento_inizio"]).": <b>".$count["count"]."</b><br>";
}else{
    $sql_count = "SELECT count(*) as count FROM ".$tabella_dati." WHERE archiviato = 0 AND Data_di_arrivo = DATE_SUB(CURDATE(),INTERVAL 13 DAY)";
    $ris_count = mysqli_query($link,$sql_count);
    $count = mysqli_fetch_array($ris_count);
    echo "Isolamenti iniziati Oggi: <b>".$count["count"]."</b><br>";
}


//$tabella_dati = "isolamenti_extra_ue";
if(isset($_POST["riferimento_inizio"]) AND $_POST["riferimento_inizio"] != ''){
    $sql = "SELECT * FROM ".$tabella_dati." WHERE Data_di_arrivo = '".$_POST["riferimento_inizio"]."' AND archiviato = 0 ORDER BY Cognome, Nome, Data_di_arrivo ASC";
    echo $sql;
}else $sql = "SELECT * FROM ".$tabella_dati." WHERE Data_di_arrivo = DATE_SUB(CURDATE(),INTERVAL 13 DAY) AND archiviato = 0 ORDER BY Cognome, Nome, Data_di_arrivo ASC";

//echo $sql."<br>";

$ris = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($ris)){
    
    $sblocca = sblocca($row["ID"],$tabella_dati,$link,$username);
    
    $fine_quarantena = quarantine($row["Data_di_arrivo"]);
    $nascita = inversa($row["Data_di_nascita"]);
    $partenza = inversa($row["Data_di_partenza"]);
    $arrivo = inversa($row["Data_di_arrivo"]);
    $compilazione = inversa($row["Data_comp"]);
    
    if($row["inizio_isolamento"] == 1 and $row["fine_isolamento"] == 0){
        echo '<tr class="iniziato">';
    }else if ($row["inizio_isolamento"] == 1 and $row["fine_isolamento"] == 1){
        echo '<tr class="finito">';
    }else echo '<tr class="elenco">';
    
    if($row["inizio_inviato"] == 1) $ai = 'SI';
    else $ai = 'NO';
    if($row["fine_inviato"] == 1) $af = 'SI';
    else $af = 'NO';
    
    if ($ai == 'SI') echo "<td class=\"si\">".$ai."</td>";
    else if($ai == 'NO') echo "<td class=\"no\">".$ai."</td>";
    
    if($af == 'SI') echo "<td class=\"si\">".$af."</td>";
    else if($af == 'NO') echo "<td class=\"no\">".$af."</td>";

    
    echo "<td>".$row["ID"]."</td><td>".$row["Cognome"]."</td><td>".$row["Nome"]."</td><td>".$nascita."</td><td>".$row["Luogo_di_nascita"]."</td><td>".$row["Codice_Fiscale"]."</td><td><a href=\"tel:".$row["Cellulare"]."\">".$row["Cellulare"]."</a></td><td><a href=\"mailto:".$row["email"]."\">".$row["email"]."</a></td><td>".$row["Paese_di_provenienza"]."</td><td>".piattaforma($row["PSA"])."</td><td>".$row["Comune_di_destinazione"]."</td><td>".$arrivo."</td>";
        
    if($fine_quarantena == date("d-m-Y"))
        echo "<td class=\"scadenza\">".$fine_quarantena."</td>";
    else echo "<td class=>".$fine_quarantena."</td>"; 
    
    echo "<td>".$row["username"]."<br>".$row["istante"]."</td>";
    echo "<td>";
        $bloccato = bloccato($row["ID"],$tabella_dati,$link);
        if($bloccato == 0){
            //Form per dettagli
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="submit" class="small" value="Dettagli">';
            echo '</form>';
        }else echo 'Bloccato';
    
    echo "</td>";
    echo "</tr>";
}




?>
</table>
<table>
    <tr><td>Legenda</td></tr>
    <tr class="iniziato"><td>Isolamento Iniziato</td></tr>
    <tr class="finito"><td>Isolamento Finito</td></tr>
    <tr><td>AI: Attestazione Inizio Isolamento Inviata</td></tr>
    <tr><td>AF: Attestazione Fine Isolamento Inviata</td></tr>
</table>
<p><a class="button" href = "logout.php">Esci</a></p>
</div>
</body>
</html>