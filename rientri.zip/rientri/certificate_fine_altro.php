<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username = $row["email"];
require_once('funzioni.php');
?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="../stile-wide.css">
		<link rel="stylesheet" type="text/css" media="print" href="./stampa.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="../stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Attestato Fine Isolamento</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione_certificato">
<!-- <img src="./intestazione.png"> -->
</div>

<p class="testo">Siracusa, <?php echo date("d-m-Y")."</p>"?>

<p class="testo">
OGGETTO: FINE ISOLAMENTO EXTRA-EUROPA E SCHENGEN
</p>
<p class="testo">
Ai sensi e agli effetti delle disposizioni vigenti riguardanti le misure per la prevenzione e gestione dell'emergenza epidemiologica in atto, aventi la finalità di contrastare e contenere il contagio del diffondersi del virus COVID-19.
</p>

<p class="attesta">SI ATTESTA</p>


<?php 
prendi_in_carico($_POST["ID"],$username,$tabella_dati,$link);
if(isset($_POST["inviato"]) AND $_POST["inviato"] == 1){
    fine_inviato($_POST["ID"],$tabella_dati,$link);
}


//$tabella_dati = "isolamenti_extra_ue"; 
$sql = "SELECT * FROM ".$tabella_dati." WHERE ID = '".$_POST["ID"]."'";

$ris = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($ris)){
    $nascita = inversa($row["Data_di_nascita"]);
    $partenza = inversa($row["Data_di_partenza"]);
    $arrivo = inversa($row["Data_di_arrivo"]);
    
    echo '<p class="testo">che il sig./sig.ra <b>'.$row["Nome"].' '.$row["Cognome"].'</b> nato/a a <b>'.$row["Luogo_di_nascita"].'</b> il <b>'.$nascita.'</b> ha superato con esito favorevole il periodo di isolamento domiciliare.';
    echo '</p>';
    
    echo '<p class="direttore">';
        echo 'Il Direttore f.f. del D.P.M<br>';
        echo '<b>*******</b>';
    echo '</p>';
    
    echo '<p class="informative">';
        echo '(Sostituisce il documento cartaceo e la firma autografa)';
    echo '</p>';
    
    echo '<p class="informative">';
        echo 'RISERVATO CONTIENE DATI SENSIBILI Informativa Privacy - Ai sensi del Regolamento UE 679/2016 si precisa che le informazioni contenute in questo messaggio sono riservate e ad uso esclusivo del destinatario. Qualora il messaggio in parola Le fosse pervenuto per errore, La preghiamo di eliminarlo senza copiarlo e di non inoltrarlo a terzi, dandocene gentilmente comunicazione. Grazie.';
    echo '</p>';
    
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="submit" class = "indietro" value="Indietro">';
            echo '</form>';
            
            echo '<form action="mailer-fine.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="inviato" value="1">';
            echo '<input type="submit" class="indietro" value="Invia">';
            echo '</form>';
            

}
                       
?>
            
            
<!-- <h2><a href = "welcome.php">Indietro</a></h2> -->
</div>
</body>
</html>