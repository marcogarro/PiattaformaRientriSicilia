<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username=$row["email"];

require_once('funzioni.php');
?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="./stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="./stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Denuncia Rientro</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Denuncia Rientro da zone a rischio
</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$nome_utente; ?></b></p>
<p><a class="button" href = "scadenza.php">In scadenza</a> <a class="button" href = "welcome.php">In isolamento</a> <a class="button" href = "nominativo.php?nominativo=">Tutti</a> <a class="button" href = "export.php">Esporta</a></p>

<?php
    $paese = $_POST["Paese_di_provenienza"];
    $cognome = stripslashes($_POST["Cognome"]);
    $nome = stripslashes($_POST["Nome"]);
    //$birth = $_POST["Data_Nascita"];
    $data_nascita = $_POST["Anno"].'-'.$_POST["Mese"].'-'.$_POST["Giorno"];
    $luogo_nascita = stripslashes($_POST["Luogo_di_nascita"]);
    $data_partenza = $_POST["P_Anno"].'-'.$_POST["P_Mese"].'-'.$_POST["P_Giorno"];
    $data_arrivo = $_POST["A_Anno"].'-'.$_POST["A_Mese"].'-'.$_POST["A_Giorno"];
    
    $sesso = $_POST["Sesso"];
    $cf = $_POST["Codice_Fiscale"];
    $luogo_residenza = stripslashes($_POST["Luogo_di_residenza"]);
    $indirizzo_residenza = stripslashes($_POST["Indirizzo_di_residenza"]);
    $cellulare = $_POST["Cellulare"];
    $email = $_POST["email"];
    
    $destinazione = stripslashes($_POST["Comune_di_destinazione"]);
    $indirizzo_destinazione = stripslashes($_POST["Indirizzo_di_destinazione"]);
    $stato_salute = stripslashes($_POST["Stato_di_salute"]);
        
        
    $sql = "SELECT count(*) as presente FROM ".$_SESSION['tab']." WHERE Cognome like '".$cognome."' AND Nome like '".$nome."' AND Data_di_nascita = '".$data_nascita."' AND Cellulare like '".$cellulare."%' AND Data_comp like CURDATE()";
    //echo $sql.'<br>';
    $ris = mysqli_query($link,$sql);
    $row = @mysqli_fetch_array($ris);
    
    //Controllo propedeutico in fase di sviluppo
    if ($row["presente"] >= 1){
        echo "DENUNCIA PRESENTE<br>";
    }
    

?>
<!-- SE UNA DENUNCIA NON E' STATA INSERITA OGGI PER LA STESSA PERSONA-->

<p class="evidenza">
Controlla i dati che hai inserito
</p>
<form action="./inserisci.php" method="POST">
	<h4 class="sezione">Dati Inseriti</h4>
	<p class="centri_vaccinali">Paese di Provenienza:
	<b><?php echo $paese; ?></b></p>
	<p class="centri_vaccinali">Cognome:
	<b><?php echo stripslashes($cognome); ?></b></p>
	<p class="centri_vaccinali">Nome:
	<b><?php echo stripslashes($nome); ?></b></p>
	
	<p class="centri_vaccinali">Data di Nascita:
	<?php 
	   
	   //list($aaaa,$mm,$gg) = explode('-',$_POST["Data_Nascita"]);
	   list($aaaa,$mm,$gg) = explode('-',$data_nascita);
	   
	   echo '<b>'.$gg.'-'.$mm.'-'.$aaaa.'</b>';
	   
	?>
    </p>
	
	<p class="centri_vaccinali">Luogo di Nascita:
	<b><?php echo $luogo_nascita; ?></b></p>
	
	<p class="centri_vaccinali">Sesso:
	<b><?php echo stripslashes($sesso); ?></b></p>
	
	<p class="centri_vaccinali">Codice Fiscale:
	<b><?php echo $cf; ?></b></p>
	
	<p class="centri_vaccinali">Luogo di Residenza:
	<b><?php echo $luogo_residenza; ?></b></p>
	<p class="centri_vaccinali">Indirizzo di Residenza:
	<b><?php echo $indirizzo_residenza; ?></b></p>
	
	<p class="centri_vaccinali">Cellulare:
	<b><?php echo $cellulare; ?></b></p>
	
	<p class="centri_vaccinali">Email:
	<b><?php echo $email; ?></b></p>
	
	<p class="centri_vaccinali">Comune di Destinazione:
	<b><?php echo $destinazione; ?></b></p>
	
	<p class="centri_vaccinali">Indirizzo di Destinazione:
	<b><?php echo $indirizzo_destinazione; ?></b></p>
	
	<p class="centri_vaccinali">Data di Partenza:
	<?php 
	   
	   //list($aaaa,$mm,$gg) = explode('-',$_POST["Data_Nascita"]);
	   list($aaaa,$mm,$gg) = explode('-',$data_partenza);
	   
	   echo '<b>'.$gg.'-'.$mm.'-'.$aaaa.'</b>';
	   
	?>
    </p>
    
    <p class="centri_vaccinali">Data di Arrivo:
	<?php 
	   
	   //list($aaaa,$mm,$gg) = explode('-',$_POST["Data_Nascita"]);
	   list($aaaa,$mm,$gg) = explode('-',$data_arrivo);
	   
	   echo '<b>'.$gg.'-'.$mm.'-'.$aaaa.'</b>';
	   
	?>
    </p>
    <p class="centri_vaccinali">Stato di Salute:
	<b><?php echo $stato_salute; ?></b></p>
	
	<input type="hidden" name="Paese" value="<?php echo $paese; ?>">
	<input type="hidden" name="Cognome" value="<?php echo $cognome; ?>">
	<input type="hidden" name="Nome" value="<?php echo $nome; ?>">
	<input type="hidden" name="Data_di_nascita" value="<?php echo $data_nascita;?>">
	<input type="hidden" name="Luogo_di_nascita" value="<?php echo $luogo_nascita;?>">
	<input type="hidden" name="Data_di_partenza" value="<?php echo $data_partenza;?>">
	<input type="hidden" name="Data_di_arrivo" value="<?php echo $data_arrivo;?>">
	<input type="hidden" name="Sesso" value="<?php echo $sesso;?>">
	<input type="hidden" name="Codice_Fiscale" value="<?php echo $cf;?>">
	<input type="hidden" name="Luogo_di_residenza" value="<?php echo $luogo_residenza;?>">
	<input type="hidden" name="Indirizzo_di_residenza" value="<?php echo $indirizzo_residenza;?>">
	<input type="hidden" name="Comune_di_destinazione" value="<?php echo $destinazione;?>">
	<input type="hidden" name="Indirizzo_di_destinazione" value="<?php echo $indirizzo_destinazione;?>">
	<input type="hidden" name="Stato_di_salute" value="<?php echo $stato_salute;?>">
	
	<input type="hidden" name="Cellulare" value="<?php echo $cellulare; ?>">
	<input type="hidden" name="email" value="<?php echo $email; ?>">
		
	<br>
	<?php 
	   echo '<input type="submit" name="Invia" value="CONFERMA">';
	?>
	
	<br>
	<p class="centri_vaccinali"><a href="./index.php">Torna alla pagina precedente</a></p>
	
</form>
<p><a class="button" href = "logout.php">Esci</a></p>
</div>
</body>
</html>
