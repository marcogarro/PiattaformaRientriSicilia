<?php
   define('DB_SERVER', 'db');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', 'zippola77');
   define('DB_DATABASE', 'rientri');
   define('TABLE', 'utenti_semp');
   $link = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

   $tabella_dati = "isolamenti_extra_ue";

?>