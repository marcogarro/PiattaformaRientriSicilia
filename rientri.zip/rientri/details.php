<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username = $row["email"];
require_once('funzioni.php');
?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="../stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="../stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Rientri</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Piattaforma Gestione Rientri</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$nome_utente; ?></b></p>

<div class="intestazione_sottotitolo">
<h5 class="sottotitolo_pagina">
Dettagli<br>
</h5>
</div>

<?php 

$in_carico = prendi_in_carico($_POST["ID"],$username,$tabella_dati,$link);


if(isset($_POST["fine_isolamento"])){
    fine($_POST["ID"],$tabella_dati,$link);
    echo '<p class="evidenza">Fine isolamento impostato</p>';
}
if(isset($_POST["inizio_isolamento"])){
    inizio($_POST["ID"],$tabella_dati,$link);
    echo '<p class="evidenza">Inizio Isolamento impostato</p>';
}
if(isset($_POST["archivia"])){
    archivia($_POST["ID"],$tabella_dati,$link);
    echo '<p class="evidenza">Soggetto archiviato</p>';
}


//$tabella_dati = "isolamenti_extra_ue"; 
$sql = "SELECT * FROM ".$tabella_dati." WHERE ID = '".$_POST["ID"]."'";
$ris = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($ris)){
    $fine_quarantena = quarantine($row["Data_di_arrivo"]);
    $nascita = inversa($row["Data_di_nascita"]);
    $partenza = inversa($row["Data_di_partenza"]);
    $arrivo = inversa($row["Data_di_arrivo"]);
    $compilazione = inversa($row["Data_comp"]);
    
    echo '<p>';
    echo "Data di Compilazione: <b>".$compilazione."</b><br>";
    echo "Cognome: <b>".$row["Cognome"]."</b><br>";
    echo "Nome: <b>".$row["Nome"]."</b><br>";
    echo "Data di Nascita: <b>".$nascita."</b><br>";
    //echo "Sesso: <b>".$row["Sesso"]."</b><br>";
    echo "Luogo di Nascita: <b>".$row["Luogo_di_nascita"]."</b><br>";
    echo "Codice Fiscale: <b>".$row["Codice_Fiscale"]."</b><br>";
    echo "Indirizzo di Residenza: <b>".$row["Indirizzo_di_residenza"]."</b><br>";
    echo "Luogo di Residenza: <b>".$row["Luogo_di_residenza"]."</b><br>";
    echo 'Cellulare: <b><a href="tel:'.$row["Cellulare"].'">'.$row["Cellulare"].'</a></b><br>';
    echo "Email: <b><a href=\"mailto:".$row["email"]."\">".$row["email"]."</a></b><br>";
    echo "Paese di Provenienza: <b>".$row["Paese_di_provenienza"]."</b><br>";
    echo "Comune di Destinazione: <b>".$row["Comune_di_destinazione"]."</b><br>";
    echo "Indirizzo di Destinazione: <b>".$row["Indirizzo_di_destinazione"]."</b><br>";
    
    //echo "Data di Partenza: <b>".$partenza."</b><br>";
    echo "Data di Arrivo: <b>".$arrivo."</b><br>";
    echo "Data di Fine Quarantena: <b>".$fine_quarantena."</b><br>";
    if($row["PSA"] == 1) $psa = "SI";
    else $psa = "NO";
    echo "Inserito in Piattaforma Sorveglianza? <b>".$psa."</b><br>";
    $note = stripslashes($row["note"]);
    echo "Note: <i>".$note."</i><br>";
    echo '</p>';
    echo '<p>';
        echo 'Ultimo aggiornamento eseguito da: <b>'.$row["username"].'</b> il <b>'.$row["istante"].'</b><br>';
    echo '</p>';
    
    
    $r = 0;
    $sql_rischio = "SELECT count(*) as rischio FROM zone_rischio WHERE denominazione = '".$row["Paese_di_provenienza"]."'";
    //echo $sql_rischio."<br>";
    $ris_rischio = mysqli_query($link,$sql_rischio);
    $rischio = @mysqli_fetch_array($ris_rischio);
    $inizio = $row["inizio_isolamento"];
    $fine = $row["fine_isolamento"];
    
    //echo $inizio.'-'.$fine;
    
    $r = $rischio["rischio"];
    //echo $r."<br>";
    echo '<p class="azioni">Azioni disponibili</p>';
    echo '<table class="dettagli">';
    echo '<tr>';
    $bloccato = bloccato($row["ID"],$tabella_dati,$link);    
    if($bloccato == 0 OR $row["username"] == $username){
        if($r == 1 and $inizio == 0 and $fine == 0){
                        //ZONE
            echo '<td class="pulsanti">';
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="inizio_isolamento" value="1">';
            echo '<input type="submit" class = "pulsante" value="Inizio Isolamento">';
            echo '</form>';
            echo '</td>';
            
        }else if($r == 1 and $inizio == 1 and $fine == 0){
            //ZONE
                echo '<td class="pulsanti">';
                echo '<form action="details.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="hidden" name="fine_isolamento" value="1">';
                echo '<input type="submit" class = "pulsante_fine" value="Fine Isolamento">';
                echo '</form>';
                echo '</td>';
            if($row["inizio_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_inizio_zone.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante" value="Attestazione Inizio">';
                echo '</form>';
                echo '</td>';
            }
        }else if($r == 0 and $inizio == 0 and $fine == 0){
            //ALTRO
            echo '<td class="pulsanti">';
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="inizio_isolamento" value="1">';
            echo '<input type="submit" class = "pulsante" value="Inizio Isolamento">';
            echo '</form>';
            echo '</td>';
        }else if($r == 0 and $inizio == 1 and $fine == 0){
            //Altro
            echo '<td class="pulsanti">';
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="fine_isolamento" value="1">';
            echo '<input type="submit" class = "pulsante_fine" value="Fine Isolamento">';
            echo '</form>';
            echo '</td>';
            if($row["inizio_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_inizio_altro.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante" value="Attestazione Inizio">';
                echo '</form>';
                echo '</td>';
            }
        }else if($r == 0 and $inizio == 1 and $fine == 1){
            if($row["fine_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_fine_altro.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante_fine" value="Attestazione Fine">';
                echo '</form>';
                echo '</td>';
            }
        }else if($r == 1 and $inizio == 1 and $fine == 1){
            if($row["fine_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_fine_zone.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante_fine" value="Attestazione Fine">';
                echo '</form>';
                echo '</td>';
            }
        }
        
    }else{
        $operatore = operatore($row["ID"],$tabella_dati,$link);
        echo '<p>Soggetto attualmente preso in carico da <b>'.$operatore.'</b></p>'; 
        $carico = 1;
     }
     echo '<td class="pulsanti">';
     echo '<form action="scadenza.php" method="post">';
     echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
     if(!isset($carico))
        echo '<input type="submit" class="pulsante_sblocca"value="Sblocca">';
     else echo '<input type="submit" class="pulsante_sblocca"value="Indietro">'; 
     echo '</form>';
     echo '</td>';
     echo '<td class="pulsanti">';
     if(!isset($carico)){
        echo '<form action="modifica.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">'; 
        echo '<input type="submit" class="pulsante_sblocca" value="Modifica">';
        echo '</form>';
     }   
     echo '</td>';
     if($row["achiviato"] == 0){
            echo '<td class="pulsanti">';
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="archivia" value="1">';
            echo '<input type="submit" class = "pulsante_sblocca" value="Archivia">';
            echo '</form>';
            echo '</td>';
        }
     echo '</tr>';
     echo '</table>';

}

           
?>
            
            
<!-- <h2><a href = "scadenza.php">Indietro</a></h2> -->
<!-- <h2><a href = "logout.php">Esci</a></h2> -->
</div>
</body>
</html>