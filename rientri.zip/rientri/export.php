<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username=$row["email"];

require_once('funzioni.php');
?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="../stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="../stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Rientri</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Piattaforma Gestione Rientri</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$nome_utente; ?></b></p>

<p><a class="button" href = "welcome.php">In isolamento</a> <a class="button" href = "scadenza.php">In scadenza</a> <a class="button" href = "nominativo.php?nominativo=">Tutti</a> <a class="button" href="anagrafica.php">Anagrafica</a></p>
<form action="scadenza.php" method="post">
    Cerca per data di fine quarantena: <input type="date" name="riferimento">
                                        <input type="submit" class="pulsante_cerca" value="Cerca">
</form>
<form action="arrivo.php" method="post">
    Cerca per data di inizio quarantena: 
                                        <input type="date" name="riferimento_inizio">
                                        <input type="submit" class="pulsante_cerca" value="Cerca">
</form>
<form action="nominativo.php" method="post">
    Cerca per cognome: 
                                        <input class="cognome" type="text" name="nominativo">
                                        <input type="submit" class="pulsante_cerca" value="Cerca">
</form>

<?php 
unlink("./export/Rientri.csv");
if(isset($_POST["ID"])){
    $sblocca = sblocca($_POST["ID"],$tabella_dati,$link,$_SESSION["username"]);
}

$sql_count = "SELECT count(*) as count FROM ".$tabella_dati." WHERE fine_isolamento=0";
//$sql_count = "SELECT count(*) as count FROM ".$tabella_dati." WHERE inizio_inviato != 1 AND fine_inviato != 1";
$ris_count = mysqli_query($link,$sql_count);
$count = mysqli_fetch_array($ris_count);
echo "In Isolamento: <b>".$count["count"]."</b><br>";

//echo '<table class="elenco">';
$riga = "ID;Cognome;Nome;Data di Nascita;Luogo di Nascita;CF;Cellulare;Email;Provenzienza;Destinazione;Indirizzo Domicilio;Data di Arrivo;Fine Quarantena;\r\n";
$date = date("Y-m-d");
$file = fopen('./export/Rientri.csv','w') or die("unable to open file");
fwrite($file,$riga);
//$tabella_dati = "isolamenti_extra_ue";
$sql = "SELECT * FROM ".$tabella_dati." WHERE fine_isolamento=0 ORDER BY Cognome, Nome, Data_di_arrivo ASC";

$ris = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($ris)){
    
    $fine_quarantena = quarantine($row["Data_di_arrivo"]);
    $nascita = inversa($row["Data_di_nascita"]);
    $partenza = inversa($row["Data_di_partenza"]);
    $arrivo = inversa($row["Data_di_arrivo"]);
    $compilazione = inversa($row["Data_comp"]);
    
    $riga = $row["ID"].";".$row["Cognome"].";".$row["Nome"].";".$nascita.";".$row["Luogo_di_nascita"].";".$row["Codice_Fiscale"].";".$row["Cellulare"].";".$row["email"].";".$row["Paese_di_provenienza"].";".$row["Comune_di_destinazione"].";".$row["Indirizzo_Domicilio"].";".$arrivo.";".$fine_quarantena.";\r\n";
    fwrite($file,$riga);
    
}
fclose($file);
$dim = round(filesize('./export/Rientri.csv')/1024);
echo '<p><a href="./export/Rientri.csv">Scarica Elenco Rientri al '.inversa(date("Y-m-d")).'</a> ('.$dim.' kB)</p>';

?>
<p><a class="button" href = "logout.php">Esci</a></p>
</div>
</body>
</html>