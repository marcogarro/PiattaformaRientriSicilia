<?php
function quarantine($data_arrivo){
            @list($anno,$mese,$giorno) = explode("-",$data_arrivo);
            $arrivo = $giorno.'-'.$mese.'-'.$anno;
        
            $giorno +=0;
            $mese+=0;
            $anno+=0;
        
            $timestamp_arrivo = mktime(0,0,0,$mese,$giorno,$anno);
            $timestamp_fine_quarantena = $timestamp_arrivo + (60*60*24*13);
            $fine_quarantena = date("d-m-Y",$timestamp_fine_quarantena);
            $liberazione = date("Y-m-d",$timestamp_fine_quarantena);
            
            return $fine_quarantena;
    }
    function inversa($data){
            @list($anno,$mese,$giorno) = explode("-",$data);
            $inversa = $giorno.'-'.$mese.'-'.$anno;
            
            return $inversa;
    }
    function doppia_inversa($data){
            @list($giorno,$mese,$anno) = explode("-",$data);
            $inversa = $anno.'-'.$mese.'-'.$giorno;
            
            return $inversa;
    }
    /*
    function prendi_in_carico($id,$username,$tab,$link){
        $sql = "UPDATE ".$tab." SET bloccato=1, username = '".$username."' WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql);
        $in_carico = 1;
        return $in_carico;
    }
    */
    function bloccato($id,$tab,$link){
        $sql = "SELECT * FROM ".$tab." WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql);
        $row = mysqli_fetch_array($ris);
        $bloccato = $row["bloccato"];
        
        return $bloccato;
    }
    
    function sblocca($id,$tab,$link,$username){
        $sql = "UPDATE ".$tab." SET bloccato=0 WHERE ID = '".$id."' AND username = '".$username."'";
        $ris = mysqli_query($link,$sql);
        
        $sbloccato = 0;
        return $sbloccato;
    }
    function piattaforma($arg){
        if($arg == 1) $ris = "SI";
        else $ris = "NO";
        
        return $ris;
    }
    function domiciliato($rientro_da,$domicilio,$link){
        
        $sql = "SELECT * FROM zone_rischio GROUP BY nomefile ORDER BY nomefile ASC";
        $ris = mysqli_query($link,$sql);
        
        while($row = mysqli_fetch_array($ris)){
            $stato = trim(strtolower($row["denominazione"]));
            $rientro_da = trim(strtolower($rientro_da));
            if($stato == $rientro_da){
                $sql_i = "SELECT * FROM comuni WHERE denominazione like '".$domicilio."%' GROUP BY nomefile";
                $ris_i = mysqli_query($link,$sql_i);
                $num = mysqli_num_rows($ris_i);
                if($num > 0){
                    $risultato = "SI";
                    return $risultato; 
                }
            } 
        }
        $risultato = "NO";
        return $risultato;
    }
    function prendi_in_carico($id,$username,$tab,$link){
        
        $h = date("H");
        $m = date("i");
        $s = date("s");
        $mese = date("m");
        $giorno = date("d");
        $anno = date("Y");
        
        $timestamp = mktime($h,$m,$s,$mese,$giorno,$anno);
        $sql = "SELECT * FROM ".$tab." WHERE ID = '".$id."'";
        //echo $sql."<br>";
        $ris = mysqli_query($link,$sql);
        $row = mysqli_fetch_array($ris);
        $istante = $timestamp;
        //if($row["username"] == $username){
        if($row["bloccato"] == 0){
            $sql = "UPDATE ".$tab." SET bloccato=1, username = '".$username."' WHERE ID = '".$id."'";
            $ris = mysqli_query($link,$sql);
            $in_carico = 1;
        }else{ 
            $in_carico = 0;
        }
        return $in_carico;
    }
    
    function operatore($id,$tab,$link){
        $sql = "SELECT username FROM ".$tab." WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql) or die("Errore");
        $row = mysqli_fetch_array($ris);
        
        return $row["username"];
    }
    
    function inizio($id,$tab,$link){
        $sql = "UPDATE ".$tab." SET inizio_isolamento = 1 WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql) or die("Errore");
    }
    function fine($id,$tab,$link){
        $sql = "UPDATE ".$tab." SET fine_isolamento = 1 WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql) or die("Errore");
    }
    function archivia($id,$tab,$link){
        $sql = "UPDATE ".$tab." SET archiviato = 1 WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql) or die("Errore");
    }
    
    function inizio_inviato($id,$tab,$link){
        $sql = "UPDATE ".$tab." SET inizio_inviato=1 WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql);
        
        $inviato = 1;
        return $inviato;
    }
    function fine_inviato($id,$tab,$link){
        $sql = "UPDATE ".$tab." SET fine_inviato=1 WHERE ID = '".$id."'";
        $ris = mysqli_query($link,$sql);
        
        $inviato = 1;
        return $inviato;
    }

    
    
?>
