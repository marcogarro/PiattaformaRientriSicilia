<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username=$row["email"];

require_once('funzioni.php');
?>
<html>
<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="./stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="./stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Denuncia Rientro</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
</head>
<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Denuncia Rientro</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$nome_utente; ?></b></p>
<p><a class="button" href = "scadenza.php">In scadenza</a> <a class="button" href = "welcome.php">In isolamento</a> <a class="button" href = "nominativo.php?nominativo=">Tutti</a> <a class="button" href = "export.php">Esporta</a></p>

<?php
    $today = date("Y-m-d");
    
    $paese = $_POST["Paese"];
    $cognome = stripslashes($_POST["Cognome"]);
    $nome = stripslashes($_POST["Nome"]);
    //$birth = $_POST["Data_Nascita"];
    $data_nascita = $_POST["Data_di_nascita"];
    $luogo_nascita = stripslashes($_POST["Luogo_di_nascita"]);
    $data_partenza = $_POST["Data_di_partenza"];
    $data_arrivo = $_POST["Data_di_arrivo"];
    
    $sesso = $_POST["Sesso"];
    $cf = $_POST["Codice_Fiscale"];
    $luogo_residenza = stripslashes($_POST["Luogo_di_residenza"]);
    $indirizzo_residenza = stripslashes($_POST["Indirizzo_di_residenza"]);
    $cellulare = $_POST["Cellulare"];
    $email = $_POST["email"];
    
    $destinazione = $_POST["Comune_di_destinazione"];
    $indirizzo_destinazione = stripslashes($_POST["Indirizzo_di_destinazione"]);
    $stato_salute = stripslashes($_POST["Stato_di_salute"]);

    
    //CONTROLLO SE IL RECORD è STATO INSERITO PER EVITARE CHE AD OGNI RELOAD SI FACCIA UN NUOVO INSERIMENTO
    $sql_check = "SELECT count(*) as allcount FROM ".$_SESSION['tab']." WHERE Data_Comp = '".$today."' AND Cognome = '".$cognome."' AND Nome = '".$nome."' AND Data_di_nascita = '".$data_nascita."'AND Cellulare = '".$cellulare."' AND email = '".$email."' AND Codice_Fiscale = '".$cf."'";
    //echo $sql_check;
    $ris_check = mysqli_query($link,$sql_check);
    $row_check = mysqli_fetch_array($ris_check);
    //$allcount è LA VARIABILE DI CONTROLLO PER VEDERE SE IL RECORD ESISTE
    $allcount = $row_check["allcount"];
    
    $sql = "INSERT INTO ".$tabella_dati."(Cognome,Nome,Data_di_nascita,Sesso,Luogo_di_nascita,Cellulare,email,Paese_di_provenienza,Comune_di_destinazione,Indirizzo_di_destinazione,Data_di_partenza,Data_di_arrivo,Stato_di_Salute,Data_comp, Codice_Fiscale, Luogo_di_residenza, Indirizzo_di_residenza, inizio_isolamento, fine_isolamento, bloccato, archiviato,inizio_inviato,fine_inviato,PSA) VALUES('".$cognome."','".$nome."','".$data_nascita."','".$sesso."','".$luogo_nascita."','".$cellulare."','".$email."','".$paese."','".$destinazione."','".$indirizzo_destinazione."','".$data_partenza."','".$data_arrivo."','".$stato_salute."','".$today."','".$cf."','".$luogo_residenza."','".$indirizzo_residenza."','0','0','0','0','0','0','0')";
    
    //echo $sql;
    if($allcount == 0){
        //IL RECORD NON ESISTE E QUINDI LO POSSO INSERIRE ED IN CASO DI ERRORE TORNO ALLA HOMEPAGE
        //echo $sql;
        $ris = mysqli_query($link,$sql) or die("ERRORE");
    }else {
        //IL RECORD ESISTE OPPURE IL CONSENSO PRIVACY è STATO NEGATO, INSERIMENTO NON VIENE EFFETTUATO
        echo '<p class="evidenza"><b>Denuncia presente</b></p>';
    }
    
    if(isset($ris)) echo '<p class="centri_vaccinali">La tua denuncia di rientro &egrave; inserita.</p>';
?>

<!-- FORM PER LA STAMPA DELLA RICEVUTA/INVIO ALLA PAGINA STAMPA-->
<!-- 
<form action="./stampa.php" method="POST">
    <input type="hidden" name="centro_vaccinale" value="<?php echo $centro_vaccinale; ?>">
	<input type="hidden" name="Cognome" value="<?php echo stripslashes($cognome); ?>">
	<input type="hidden" name="Nome" value="<?php echo stripslashes($nome); ?>">
	<input type="hidden" name="Medico" value="<?php echo stripslashes($medico); ?>">
	<input type="hidden" name="Data_Nascita" value="<?php echo $_POST["Data_Nascita"]; ?>">
	<input type="hidden" name="Telefono" value="<?php echo $telefono; ?>">
	<input type="hidden" name="Email" value="<?php echo $email; ?>">
	<input type="hidden" name="Compilatore" value="<?php echo stripslashes($compilatore); ?>">
	<input type="hidden" name="Privacy" value="<?php echo $_POST["Privacy"]; ?>">
	<input type="submit" name="Invia" value="STAMPA RICEVUTA">
</form>
-->

<p class="centri_vaccinali"><a href="./anagrafica.php">Inserisci una nuova richiesta</a></p>
<p><a class="button" href = "logout.php">Esci</a></p>
</div>
</body>
</html>
