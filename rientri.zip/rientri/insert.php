<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username = $row["email"];
require_once('funzioni.php');
?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="../stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="../stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Rientri 1.0</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Piattaforma Gestione Rientri</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$username; ?></b></p>

<div class="intestazione_sottotitolo">
<h5 class="sottotitolo_pagina">
Update<br>
</h5>
</div>

<?php 
   
   $cognome = addslashes($_POST["cognome"]);
   $nome = addslashes($_POST["nome"]);
   $luogo_nascita = addslashes($_POST["luogo_nascita"]);
   $cf = addslashes($_POST["cf"]);
   $indirizzo_residenza = addslashes($_POST["indirizzo_residenza"]);
   $luogo_residenza = addslashes($_POST["luogo_residenza"]);
   $cellulare = addslashes($_POST["cellulare"]);
   $email = addslashes($_POST["email"]);
   $provenienza = addslashes($_POST["provenienza"]);
   $destinazione = addslashes($_POST["destinazione"]); 
   $indirizzo_destinazione = addslashes($_POST["indirizzo_destinazione"]); 
   $note = addslashes($_POST["note"]);
   $nascita = $_POST["nascita"];
   $data_arrivo = $_POST["data_arrivo"];
   
   
   $sql = "UPDATE ".$tabella_dati." SET Cognome = '".$cognome."', Nome = '".$nome."', Data_di_nascita = '".$nascita."', Luogo_di_nascita = '".$luogo_nascita."', Codice_Fiscale = '".$cf."', Indirizzo_di_residenza = '".$indirizzo_residenza."', Luogo_di_residenza = '".$luogo_residenza."', Cellulare = '".$cellulare."', email = '".$email."', Paese_di_provenienza = '".$provenienza."', Comune_di_destinazione = '".$destinazione."', Indirizzo_di_destinazione = '".$indirizzo_destinazione."', Data_di_arrivo = '".$data_arrivo."', note = '".$note."', PSA = '".$_POST["psa"]."' WHERE ID = '".$_POST["ID"]."'";
   //echo $sql."<br>";
   
   
   $ris = mysqli_query($link,$sql) or die("ERRORE");
   
   echo "<p>AGGIORNAMENTO ESEGUITO</p>";
   echo '<p>';
    
   echo '</p>';
   echo '<table class="dettagli">';
   echo '<tr>';
    echo '<td class="pulsanti">';
        echo '<form action="details.php" method="post">';
        echo '<input type="hidden" name="ID" value="'.$_POST["ID"].'">';
        echo '<input type="submit" class="pulsante_sblocca"value="Torna al Record in Esame">';
    echo '</form>';
    echo '</td>';
   echo '</tr>';
   echo '<tr>';
   echo '<td class="pulsanti">';
   echo '<form action="scadenza.php" method="post">';
   echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
   echo '<input type="submit" class="pulsante_sblocca"value="Indietro">'; 
   echo '</form>';
   echo '</tr>';
   echo '</table>';


           
?>
            
            
<!-- <h2><a href = "scadenza.php">Indietro</a></h2> -->
<!-- <h2><a href = "logout.php">Esci</a></h2> -->
</div>
</body>
</html>