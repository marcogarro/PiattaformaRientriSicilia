<?php
/*
@package : Login PHP dan Mysqli
@author  : Fika Ridaul Maulayya
@since   : 2016
@license : https://www.rubypedia.com
*/

//membuat deklarasi variable
$hostname = "db";
$username = "root";
//$password = $_SERVER['PASSWORD'];
$password = 'la_tua_password';
$database = "rientri";
$tabella_dati = "isolamenti_extra_ue";

//create variable connectin
$connection = mysqli_connect($hostname, $username, $password, $database);
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

/*The closing ?> tag MUST be omitted from files containing only PHP.
 Reff http://www.php-fig.org/psr/psr-2/#22-files
 ?>
 */
