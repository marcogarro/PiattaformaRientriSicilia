<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username = $row["email"];
require_once('funzioni.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';
$data_invio = date('d-m-Y');
$today = date('Y-m-d');
$nowday = date('Ymd');

$sql = "SELECT * FROM ".$tabella_dati." WHERE ID = '".$_POST["ID"]."'";
$ris = mysqli_query($link,$sql);

while($row = mysqli_fetch_array($ris)){

$mail = new PHPMailer(true);
	try {
    	$mail->isSMTP();                                            // Send using SMTP
    	$mail->Host       = 'tuo_host';                    // Set the SMTP server to send through
    	$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    	$mail->Username   = 'tua_username';                     // SMTP username
    	$mail->Password   = 'tua_password';                               // SMTP password
    	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    	//$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    	$mail->Port       = 587;

	    //Recipients
	    $destinatario = $row["Nome"]." ".$row["Cognome"];
	    $indirizzo = $row["email"];
    	$mail->setFrom('tuo_mittente', 'ASP SR - Attestazioni');
    	$mail->addAddress($row['email'], $destinatario);     // Add a recipient
    	//$mail->addAddress('marcogarro@pec.it', 'Marco Garro');     // Add a recipient
    	$mail->addReplyTo('tuo_mittente', 'ASP SR - Invio Elenchi');
    	//$mail->addCC('cc@example.com');
    	//$mail->addBCC('bcc@example.com');

    	// Attachments
    	
    	//$mail->addAttachment('./'.$today.'-'.$row["nomefile"].'_isolamento.csv.gpg');
    	
    	
    	// Content
    	$mail->isHTML(true);                                  // Set email format to HTML
    	$mail->Subject = "Trasmissione Attestazione del ".$data_invio."";
    	$mail->Body    = 'TESTO DELLA MAIL<br>';
    	//$mail->Body    = 'La comunicazione degli isolamenti da contatto con positivi sar&agrave; comunicata quando ci saranno aggiornamenti.<br>';
    	
    	$mail->send();
    	
    	$sql_in = "UPDATE ".$tabella_dati." SET fine_inviato=1 WHERE ID='".$_POST["ID"]."'";
       	echo $sql_in;
    	$ris_is = mysqli_query($link,$sql_in) or die("ERRORE MEMORIZZAZIONE FINE INVIATO SU DB<br>");
    	
	} catch (Exception $e) {
    	echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
	}
}
?>
    	<html>
        <head>
        <link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="../stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="../stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Rientri 1.0</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

        </head>

        <body>

        <div class="contenitore">
        <div class="intestazione">
        <h2 class="titolo_pagina">
        ASP di Siracusa<br>
        Piattaforma Gestione Rientri</h2>
        </div>
        <p><?php echo "Utente in sessione: <b>".$username; ?></b></p>

        <div class="intestazione_sottotitolo">
        <h5 class="sottotitolo_pagina">
        Email a <?php echo $destinatario; ?> Inviata<br>
        </h5>
        </div>
        <table>
            <tr>
                <td class="pulsanti">
                    <?php
                        echo '<form action="scadenza.php" method="post">';
                        echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                        if(!isset($carico))
                            echo '<input type="submit" class="pulsante_sblocca" value="Sblocca">';
                        else echo '<input type="submit" class="pulsante_sblocca" value="Indietro">'; 
                        echo '</form>';
                    ?>
        </td>
        </tr>
        </table>
        </body>
        </html>











