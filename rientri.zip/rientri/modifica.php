<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');
$link = $connection;
$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);
$nome_utente = $row["nama"];
$username = $row["email"];
require_once('funzioni.php');
?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="../stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="../stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Rientri 1.0</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Piattaforma Gestione Rientri</h2>
</div>
<p><?php echo "Utente in sessione: <b>".$username; ?></b></p>

<div class="intestazione_sottotitolo">
<h5 class="sottotitolo_pagina">
Dettagli<br>
</h5>
</div>

<?php 

$in_carico = prendi_in_carico($_POST["ID"],$username,$tabella_dati,$link);

if(isset($_POST["fine_isolamento"])){
    fine($_POST["ID"],$tabella_dati,$link);
}
if(isset($_POST["inizio_isolamento"])){
    inizio($_POST["ID"],$tabella_dati,$link);
}


//$tabella_dati = "isolamenti_extra_ue"; 
$sql = "SELECT * FROM ".$tabella_dati." WHERE ID = '".$_POST["ID"]."'";

$ris = mysqli_query($link,$sql);
echo '<form action="insert.php" method="post">';
while($row = mysqli_fetch_array($ris)){
    $fine_quarantena = quarantine($row["Data_di_arrivo"]);
    $nascita = inversa($row["Data_di_nascita"]);
    $partenza = inversa($row["Data_di_partenza"]);
    $arrivo = inversa($row["Data_di_arrivo"]);
    $compilazione = inversa($row["Data_comp"]);
    
    echo '<table class="modifica">';
    //echo "Data di Compilazione: <b>".$compilazione."</b><br>";
    echo '<tr class="elenco">';
    echo "<td>Cognome:</td> <td><input name=\"cognome\" class=\"modifica\" type=\"text\" value=\"".$row["Cognome"]."\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Nome:</td> <td><input name=\"nome\" class=\"modifica\" type=\"text\" value=\"".$row["Nome"]."\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Data di Nascita:</td> <td><input name=\"nascita\" class=\"modifica\" type=\"date\" value=\"".$row["Data_di_nascita"]."\"></td>";
    //echo "Sesso: <b>".$row["Sesso"]."</b></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Luogo di Nascita:</td> <td><input name=\"luogo_nascita\" class=\"modifica\" type=\"text\" value=\"".$row["Luogo_di_nascita"]."\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Codice Fiscale:</td> <td><input name=\"cf\" class=\"modifica\" type=\"text\" value=\"".$row["Codice_Fiscale"]."\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Indirizzo di Residenza:</td><td> <input name=\"indirizzo_residenza\" class=\"modifica\" type=\"text\" value=\"".$row["Indirizzo_di_residenza"]."\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Luogo di Residenza:</td> <td><input name=\"luogo_residenza\" class=\"modifica\" type=\"text\" value=\"".$row["Luogo_di_residenza"]."\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Cellulare:</td> <td><input name=\"cellulare\" class=\"modifica\" type=\"text\" value=\"".$row["Cellulare"]."\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Email:</td><td> <input name=\"email\" class=\"modifica\" type=\"text\" value=\"".$row["email"]."\"\"></td>";
    echo '</tr>';
    echo '<tr class="elenco">';
    //echo "<td>Paese di Provenienza:</td><td> <input name=\"provenienza\" class=\"modifica\" type=\"text\" value=\"".$row["Paese_di_provenienza"]."\"></td>";
    echo "<td>Paese di Provenienza:</td><td>";
    $sql = "SELECT stato FROM nazioni ORDER BY stato ASC";
		$ris = mysqli_query($link,$sql);
		echo '<select name="provenienza">';
		while($row_s = mysqli_fetch_array($ris)){
		  //echo '<div class="centri_vaccinali">';
		  //echo '<input type="radio"  name="Paese_di_provenienza" value="'.$row["nomefile"].'" required>';
          //echo '<label for="'.$row["nomefile"].'" class="scelta">'.$row["denominazione"].'</label>';
          //echo '</div>';
          $prov = trim(ucfirst(strtolower($row["Paese_di_provenienza"])));
          //if($row_s["stato"] == $row["Paese_di_provenienza"])
          if(trim($row_s["stato"]) == $prov)
            echo '<option value="'.$row_s["stato"].'" selected>'.$row_s["stato"].'</option>';
          else echo '<option value="'.$row_s["stato"].'">'.$row_s["stato"].'</option>'; 
		}
		echo '</select>';
    echo '</td>';
    echo '</tr>';
    echo '<tr class="elenco">';
    //echo "<td>Comune di Destinazione:</td><td> <input name=\"destinazione\" class=\"modifica\" type=\"text\" value=\"".$row["Comune_di_destinazione"]."\"></td>";
    
    echo "<td>Comune di Destinazione:</td>";
    echo '<td>';
                echo '<select name="destinazione">';
                $sql_c = "SELECT * FROM comuni GROUP BY nomefile ORDER BY nomefile ASC";
				$ris_c = mysqli_query($link,$sql_c);
				while($row_c = mysqli_fetch_array($ris_c)){
				    $den = trim(strtolower($row_c["denominazione"]));
				    $com = trim(strtolower($row["Comune_di_destinazione"]));
				    //echo $den."".$com;
				    if($den == $com) echo '<option value="'.$row_c["denominazione"].'" selected>'.$row_c["denominazione"].'</option>';
				    else echo '<option value="'.$row_c["denominazione"].'">'.$row_c["denominazione"].'</option>';
				}
				echo '</select>';
				
    echo '</td>';
   
    echo '</tr>';
    echo '<tr class="elenco">';
    echo "<td>Indirizzo di Destinazione:</td><td> <input name=\"indirizzo_destinazione\" class=\"modifica\" type=\"text\" value=\"".$row["Indirizzo_di_destinazione"]."\"></td>";
    echo '</tr>';
    //echo "Data di Partenza: <b>".$partenza."</b></td>";
    echo '<tr class="elenco">';
    echo "<td>Data di Arrivo:</td><td> <input name=\"data_arrivo\" class=\"modifica\" type=\"date\" value=\"".$row["Data_di_arrivo"]."\"></td>";
    echo '</tr>';
    echo '<tr>';
    echo '<td>Note: </td>';
    $note = stripslashes($row["note"]);
    echo '<td><textarea class="modifica" name="note" rows="10" cols="50">'.$note.'</textarea></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<td>Inserito in Piattaforma Sorveglianza? </td>';
    echo '<td>';
    echo '<select name="psa">';
        if($row["PSA"] == 1){
            echo '<option value="1" selected>SI</option>';
            echo '<option value="0">NO</option>';
        }else if($row["PSA"] == 0){
            echo '<option value="0" selected>NO</option>';
            echo '<option value="1" >SI</option>';
        }
        
    echo '</select>';
    echo '</td>';
    echo '</tr>';
    //echo "Data di Fine Quarantena: ".$fine_quarantena."</b><br>";
    echo '<input type="hidden" name="ID" value="'.$_POST["ID"].'">';
    echo '<tr><td class="pulsanti"><input type="submit" class="pulsante_sblocca" value="Aggiorna"></td></tr>';
    echo '</table>';
echo '</form>';
    
    $r = 0;
    $sql_rischio = "SELECT count(*) as rischio FROM zone_rischio WHERE denominazione = '".$row["Paese_di_provenienza"]."'";
    //echo $sql_rischio."<br>";
    $ris_rischio = mysqli_query($link,$sql_rischio);
    $rischio = mysqli_fetch_array($ris_rischio);
    $inizio = $row["inizio_isolamento"];
    $fine = $row["fine_isolamento"];
    
    //echo $inizio.'-'.$fine;
    
    $r = $rischio["rischio"];
    //echo $r."<br>";
    echo '<p class="azioni">Azioni disponibili</p>';
    echo '<table class="dettagli">';
    echo '<tr>';
    $bloccato = bloccato($row["ID"],$tabella_dati,$link);
    if($bloccato == 0 OR $row["username"] == $username){
        if($r == 1 and $inizio == 0 and $fine == 0){
                        //ZONE
            echo '<td class="pulsanti">';
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="inizio_isolamento" value="1">';
            echo '<input type="submit" class = "pulsante" value="Inizio Isolamento">';
            echo '</form>';
            echo '</td>';
            
        }else if($r == 1 and $inizio == 1 and $fine == 0){
            //ZONE
                echo '<td class="pulsanti">';
                echo '<form action="details.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="hidden" name="fine_isolamento" value="1">';
                echo '<input type="submit" class = "pulsante_fine" value="Fine Isolamento">';
                echo '</form>';
                echo '</td>';
            if($row["inizio_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_inizio_zone.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante" value="Attestazione Inizio">';
                echo '</form>';
                echo '</td>';
            }
        }else if($r == 0 and $inizio == 0 and $fine == 0){
            //ALTRO
            echo '<td class="pulsanti">';
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="inizio_isolamento" value="1">';
            echo '<input type="submit" class = "pulsante" value="Inizio Isolamento">';
            echo '</form>';
            echo '</td>';
        }else if($r == 0 and $inizio == 1 and $fine == 0){
            //Altro
            echo '<td class="pulsanti">';
            echo '<form action="details.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
            echo '<input type="hidden" name="fine_isolamento" value="1">';
            echo '<input type="submit" class = "pulsante_fine" value="Fine Isolamento">';
            echo '</form>';
            echo '</td>';
            if($row["inizio_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_inizio_altro.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante" value="Attestazione Inizio">';
                echo '</form>';
                echo '</td>';
            }
        }else if($r == 0 and $inizio == 1 and $fine == 1){
            if($row["fine_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_fine_altro.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante_fine" value="Attestazione Fine">';
                echo '</form>';
                echo '</td>';
            }
        }else if($r == 1 and $inizio == 1 and $fine == 1){
            if($row["fine_inviato"] == 0){
                echo '<td class="pulsanti">';
                echo '<form action="certificate_fine_zone.php" method="post">';
                echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
                echo '<input type="submit" class = "pulsante_fine" value="Attestazione Fine">';
                echo '</form>';
                echo '</td>';
            }
        }
    }else{
        $operatore = operatore($row["ID"],$tabella_dati,$link);
        echo '<p>Soggetto attualmente preso in carico da <b>'.$operatore.'</b></p>'; 
        $carico = 1;
     }
     echo '<td class="pulsanti">';
     echo '<form action="scadenza.php" method="post">';
     echo '<input type="hidden" name="ID" value="'.$row["ID"].'">';
     if(!isset($carico))
        echo '<input type="submit" class="pulsante_sblocca"value="Sblocca">';
     else echo '<input type="submit" class="pulsante_sblocca"value="Indietro">'; 
     echo '</form>';
     echo '</td>';
     echo '<td class="pulsanti">';
     if(!isset($carico)){
        echo '<form action="modifica.php" method="post">';
            echo '<input type="hidden" name="ID" value="'.$row["ID"].'">'; 
        echo '<input type="submit" class="pulsante_sblocca" value="Modifica">';
        echo '</form>';
     }
     echo '</td>';
     echo '</tr>';
     echo '</table>';

}

           
?>
            
            
<!-- <h2><a href = "scadenza.php">Indietro</a></h2> -->
<!-- <h2><a href = "logout.php">Esci</a></h2> -->
</div>
</body>
</html>