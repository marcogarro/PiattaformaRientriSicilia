<?php
session_start();
$_SESSION['con']=1;
$_SESSION['host'] = '62.149.150.134';
$_SESSION['user'] = 'Sql463815';
$_SESSION['psw'] = 'e4f70fe7';
$_SESSION['db'] = 'Sql463815_1';
$_SESSION['tab'] = 'prenotazioni';


function connect_db(){
	global $link;	
	$link=mysqli_connect($_SESSION['host'], $_SESSION['user'], $_SESSION['psw'], $_SESSION['db']);
	if (mysqli_connect_errno($_SESSION['con']))
	{
		  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	  return false;
	} else return $link;
}
$link = connect_db();

?>
<html>

<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
		<link rel="stylesheet" type="text/css" media="screen and (min-width:601px)" href="./stile-wide.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width:600px)" href="./stile-narrow.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<title>Prenotazione Vaccinazione</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

</head>

<body>

<div class="contenitore">
<div class="intestazione">
<h2 class="titolo_pagina">
ASP di Siracusa<br>
Ricevuta Richiesta di Prenotazione Vaccinazione
</h2>
</div>

<?php 
    $today = date("Y-m-d");
    $oggi = date("Ymd");
    $sql = "SELECT * FROM ".$_SESSION['tab']." WHERE giorno = '".$today."' AND compilatore = '".$_POST['Compilatore']."' AND CV = '".$_POST['centro_vaccinale']."' AND Cognome = '".$_POST['Cognome']."' AND Nome = '".$_POST['Nome']."' AND Medico = '".$_POST['Medico']."'";
    //echo $sql.'<br>';
    $ris = mysqli_query($link,$sql) or die('<meta http-equiv="refresh" content="0; url=http://www.pretorio.net/prenotazioni/dev/index.php">');
    $row = mysqli_fetch_array($ris); 
?>
    <h4 class="sezione">ID Prenotazione</h4>
    <p class="centri_vaccinali">ID: <b><?php echo $oggi.'-'.$row['ID_vacc']; ?></b></p>
	<h4 class="sezione">Centro Vaccinale Scelto</h4>
	<p class="centri_vaccinali">Centro:
	<b><?php echo $_POST["centro_vaccinale"]; ?></b></p>
	<h4 class="sezione">Dati di chi deve effettuare la vaccinazione</h4>
	<p class="centri_vaccinali">Cognome:
	<b><?php echo stripslashes($_POST["Cognome"]); ?></b></p>
	
	<p class="centri_vaccinali">Nome:
	<b><?php echo stripslashes($_POST["Nome"]); ?></b></p>
	
	<p class="centri_vaccinali">Data di Nascita:
	<?php 
	   
	   list($aaaa,$mm,$gg) = explode('-',$_POST["Data_Nascita"]);
	   
	   echo '<b>'.$gg.'-'.$mm.'-'.$aaaa.'</b>';
	   
	?>
    </p>
	
	<p class="centri_vaccinali">PLS/MMG:
	<b><?php echo stripslashes($_POST["Medico"]); ?></b></p>
	
	<p class="centri_vaccinali">Telefono:
	<b><?php echo $_POST["Telefono"]; ?></b></p>
	
	<p class="centri_vaccinali">Email:
	<b><?php echo $_POST["Email"]; ?></b></p>
	
	<h4 class="sezione">Autorizzazione al trattamento dei dati personali</h4>
	<p class="centri_vaccinali">Compilatore:
	<b><?php echo stripslashes($_POST["Compilatore"]); ?></b></p>
	<p class="centri_vaccinali">Consenso accordato: <b><?php echo $_POST["Privacy"]; ?></b></p>
	
	<p class="centri_vaccinali"><a href="./index.php">Inserisci una nuova richiesta</a></p>

	
</div>
</body>
</html>
